<?php
define('APIENDPOINT', "https://neo.fuljor.com/metroapi/v1/controller/");
