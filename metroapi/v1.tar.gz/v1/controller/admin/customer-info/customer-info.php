<?php


include_once('../../db.php');
include_once('../../../model/admin/customer-info/customer-infoModel.php');
include_once('../../../model/response.php');

$allHeaders = getallheaders();
$apiSecurity = $allHeaders['Authorization'];
if ($apiKey != $apiSecurity) {
    $response = new Response();
    $response->setHttpStatusCode(401);
    $response->setSuccess(false);
    $response->addMessage("API Security Key Doesn't exist.");
    $response->send();
    exit;
}
try {
    $writeDB = DB::connectWriteDB();
    $readDB = DB::connectReadDB();
} catch (PDOException $ex) {
    error_log("Connection error - " . $ex, 0);
    $response = new Response();
    $response->setHttpStatusCode(500);
    $response->setSuccess(false);
    $response->addMessage("Database Connection Error");
    $response->send();
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === "POST") {
    try {
        if ($_SERVER['CONTENT_TYPE'] !== 'application/json') {
            $response = new Response();
            $response->setHttpStatusCode(400);
            $response->setSuccess(false);
            $response->addMessage("Content type header is not set to JSON");
            $response->send();
            exit();
        }
        $rawPostData = file_get_contents('php://input');
        if (!$jsonData = json_decode($rawPostData)) {
            $response = new Response();
            $response->setHttpStatusCode(400);
            $response->setSuccess(false);
            $response->addMessage("Request body is not valid JSON");
            $response->send();
            exit();
        }
        $debtorInfo = new DebtorMaster($jsonData->debtorno, $jsonData->cm_id, $jsonData->name, $jsonData->address1, $jsonData->address2, $jsonData->address3, $jsonData->address3, $jsonData->address4, $jsonData->address5, $jsonData->address6, $jsonData->login_id, $jsonData->currcode, $jsonData->salestype, $jsonData->$clientsince, $jsonData->holdreason, $jsonData->paymentterms, $jsonData->discount, $jsonData->pymtdiscount, $jsonData->lastpaid, $jsonData->lastpaiddate, $jsonData->creditlimit, $jsonData->invaddrbranch, $jsonData->discountcode, $jsonData->ediinvoices, $jsonData->ediorders, $jsonData->edireference, $jsonData->editransport, $jsonData->ediaddress, $jsonData->ediserveruser, $jsonData->ediserverpwd, $jsonData->taxref, $jsonData->customerpoline, $jsonData->typeid, $jsonData->customer_note, $jsonData->custcatid1, $jsonData->op_bal, $jsonData->phone1, $jsonData->phone2, $jsonData->email, $jsonData->created_by, $jsonData->created_at, $jsonData->updated_at, $jsonData->updated_by, $jsonData->status, $jsonData->bin_no, $jsonData->nid_no, $jsonData->user_token);
        $debtorno = $debtorInfo->getDebtorno();
        $cm_id = $debtorInfo->getCm_id();
        $name = $debtorInfo->getName();
        $address1 = $debtorInfo->getAddress1();
        $address2 = $debtorInfo->getAddress2();
        $address3 = $debtorInfo->getAddress3();
        $address4 = $debtorInfo->getAddress4();
        $address5 = $debtorInfo->getAddress5();
        $address6 = $debtorInfo->getAddress6();
        $login_media = $debtorInfo->getLogin_media();
        $login_id = $debtorInfo->getLogin_id();
        $currcode = $debtorInfo->getCurrcode();
        $salestype = $debtorInfo->getSalestype();
        $clientsince = $debtorInfo->getClientsince();
        $holdreason = $debtorInfo->getHoldreason();
        $paymentterms = $debtorInfo->getPaymentterms();
        $discount = $debtorInfo->getDiscount();
        $pymtdiscount = $debtorInfo->getPymtdiscount();
        $lastpaid = $debtorInfo->getLastpaid();
        $lastpaiddate = $debtorInfo->getLastpaiddate();
        $creditlimit = $debtorInfo->getCreditlimit();
        $invaddrbranch = $debtorInfo->getInvaddrbranch();
        $discountcode = $debtorInfo->getDiscountcode();
        $ediinvoices = $debtorInfo->getEdiinvoices();
        $ediorders = $debtorInfo->getEdiorders();
        $edireference = $debtorInfo->getEdireference();
        $editransport = $debtorInfo->getEditransport();
        $ediaddress = $debtorInfo->getEdiaddress();
        $ediserveruser = $debtorInfo->getEdiserveruser();
        $ediserverpwd = $debtorInfo->getEdiserverpwd();
        $taxref = $debtorInfo->getTaxref();
        $customerpoline = $debtorInfo->getCustomerpoline();
        $typeid = $debtorInfo->getTypeid();
        $customer_note = $debtorInfo->getCustomer_note();
        $custcatid1 = $debtorInfo->getCustcatid1();
        $op_bal = $debtorInfo->getOp_bal();
        $phone1 = $debtorInfo->getPhone1();
        $phone2 = $debtorInfo->getPhone2();
        $email = $debtorInfo->getEmail();
        $created_by = $debtorInfo->getCreated_by();
        $created_at = $debtorInfo->getCreated_at();
        $updated_at = $debtorInfo->getUpdated_at();
        $updated_by = $debtorInfo->getUpdated_by();
        $status = $debtorInfo->getStatus();
        $bin_no = $debtorInfo->getBin_no();
        $nid_no = $debtorInfo->getNid_no();
        $user_token = $debtorInfo->getUser_token();
        $query = "INSERT INTO debtorsmaster(debtorno, cm_id, name, address1,address2,address3,address4,address5,address6, login_id, currcode, salestype, clientsince, holdreason, paymentterms, discount, pymtdiscount, lastpaid, lastpaiddate, creditlimit, invaddrbranch, discountcode, ediinvoices, ediorders, edireference, editransport, customerpoline, typeid, custcatid1, op_bal, phone1, phone2, email, created_by, created_at, updated_at, updated_by, status, bin_no, nid_no, user_token)VALUES(:debtorno, :cm_id, :name, :address1, :address2, :address3, :address4, :address5, :address6, :login_id, :currcode, :salestype, :clientsince, :holdreason, :paymentterms, :discount, :pymtdiscount, :lastpaid, :lastpaiddate, :creditlimit, :invaddrbranch, :discountcode, :ediinvoices, :ediorders, :edireference, :editransport, :customerpoline, :typeid, :custcatid1, :op_bal, :phone1, :phone2, :email, :created_by, :created_at, :updated_at, :updated_by, :status, :bin_no, :nid_no, :user_token
        )";

        $insertDebtorStmt = $writeDB->prepare($query);
        $insertDebtorStmt->bindParam(':debtorno', $debtorno, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':cm_id', $cm_id, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':name', $name, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':address1', $address1, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':address2', $address2, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':address3', $address3, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':address4', $address4, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':address5', $address5, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':address6', $address6, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':login_id', $login_id, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':currcode', $currcode, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':salestype', $salestype, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':clientsince', $clientsince, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':holdreason', $holdreason, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':paymentterms', $paymentterms, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':discount', $discount, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':pymtdiscount', $pymtdiscount, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':lastpaid', $lastpaid, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':lastpaiddate', $lastpaiddate, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':creditlimit', $creditlimit, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':invaddrbranch', $invaddrbranch, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':discountcode', $discountcode, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':ediinvoices', $ediinvoices, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':ediorders', $ediorders, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':edireference', $edireference, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':editransport', $editransport, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':customerpoline', $customerpoline, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':typeid', $typeid, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':custcatid1', $custcatid1, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':op_bal', $op_bal, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':phone1', $phone1, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':phone2', $phone2, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':email', $email, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':created_by', $created_by, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':created_at', $created_at, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':updated_at', $updated_at, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':updated_by', $updated_by, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':status', $status, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':bin_no', $bin_no, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':nid_no', $nid_no, PDO::PARAM_STR);
        $insertDebtorStmt->bindParam(':user_token', $user_token, PDO::PARAM_STR);
        $insertDebtorStmt->execute();
    } catch (CustomerException $ex) {
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(false);
        $response->addMessage($ex->getMessage());
        $response->send();
        exit();
    } catch (PDOException $ex) {
        error_log("Database query error." . $ex, 0);
        $response = new Response();
        $response->setHttpStatusCode(500);
        $response->setSuccess(false);
        $response->addMessage($ex->getMessage());
        $response->send();
    }
} else {
    $response = new Response();
    $response->setHttpStatusCode(404);
    $response->setSuccess(false);
    $response->addMessage("Endpoint not found");
    $response->send();
    exit;
}
